import pytest
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from app import create_app
from extensions import db as _db
from config import Config

class TestConfig(Config):
    TESTING                  = True
    SQLALCHEMY_DATABASE_URI  = "sqlite:///:memory:"
    JWT_SECRET_KEY           = "test-jwt-key"
    AES_SECRET_KEY           = b"12345678901234567890123456789012"
    BCRYPT_LOG_ROUNDS        = 4   # Fast rounds for tests
    MAX_LOGIN_ATTEMPTS       = 3
    LOCKOUT_MINUTES          = 1


@pytest.fixture(scope="module")
def app():
    app = create_app(TestConfig)
    with app.app_context():
        _db.create_all()
        yield app
        _db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


VALID_USER = {
    "name":     "Aditya Dhadiwal",
    "email":    "aditya@example.com",
    "password": "Secure@123"
}


# ── Registration ──────────────────────────────────────────────────────────────

class TestRegister:
    def test_successful_registration(self, client):
        res = client.post("/api/auth/register", json=VALID_USER)
        assert res.status_code == 201
        assert "donor_id" in res.get_json()

    def test_duplicate_email_rejected(self, client):
        client.post("/api/auth/register", json=VALID_USER)
        res = client.post("/api/auth/register", json=VALID_USER)
        assert res.status_code == 409
        assert "already registered" in res.get_json()["error"]

    def test_missing_fields_rejected(self, client):
        res = client.post("/api/auth/register", json={"email": "x@x.com"})
        assert res.status_code == 400

    def test_invalid_email_rejected(self, client):
        res = client.post("/api/auth/register", json={
            "name": "Test", "email": "notanemail", "password": "Secure@123"
        })
        assert res.status_code == 400

    def test_weak_password_no_uppercase(self, client):
        res = client.post("/api/auth/register", json={
            "name": "Test", "email": "weak1@x.com", "password": "nouppercase1!"
        })
        assert res.status_code == 400
        assert "uppercase" in res.get_json()["error"].lower()

    def test_weak_password_no_digit(self, client):
        res = client.post("/api/auth/register", json={
            "name": "Test", "email": "weak2@x.com", "password": "NoDigitHere!"
        })
        assert res.status_code == 400
        assert "digit" in res.get_json()["error"].lower()

    def test_weak_password_no_special_char(self, client):
        res = client.post("/api/auth/register", json={
            "name": "Test", "email": "weak3@x.com", "password": "NoSpecial1"
        })
        assert res.status_code == 400
        assert "special" in res.get_json()["error"].lower()

    def test_weak_password_too_short(self, client):
        res = client.post("/api/auth/register", json={
            "name": "Test", "email": "weak4@x.com", "password": "Ab1!"
        })
        assert res.status_code == 400
        assert "8 characters" in res.get_json()["error"]


# ── Login ─────────────────────────────────────────────────────────────────────

class TestLogin:
    @pytest.fixture(autouse=True)
    def create_user(self, client):
        client.post("/api/auth/register", json={
            "name": "Harshit Jain", "email": "harshit@example.com", "password": "Secure@123"
        })

    def test_successful_login_returns_jwt(self, client):
        res = client.post("/api/auth/login", json={
            "email": "harshit@example.com", "password": "Secure@123"
        })
        assert res.status_code == 200
        data = res.get_json()
        assert "access_token" in data
        assert data["name"] == "Harshit Jain"

    def test_wrong_password_rejected(self, client):
        res = client.post("/api/auth/login", json={
            "email": "harshit@example.com", "password": "WrongPass@1"
        })
        assert res.status_code == 401
        assert "Invalid" in res.get_json()["error"]

    def test_unknown_email_rejected(self, client):
        res = client.post("/api/auth/login", json={
            "email": "nobody@example.com", "password": "Secure@123"
        })
        assert res.status_code == 401

    def test_brute_force_lockout(self, client):
        # Register a separate user to test lockout without affecting others
        client.post("/api/auth/register", json={
            "name": "Lockout Test", "email": "lockout@example.com", "password": "Secure@123"
        })
        for _ in range(3):
            client.post("/api/auth/login", json={
                "email": "lockout@example.com", "password": "Wrong@Pass1"
            })
        # 4th attempt should say account is locked
        res = client.post("/api/auth/login", json={
            "email": "lockout@example.com", "password": "Wrong@Pass1"
        })
        assert res.status_code == 401
        assert "locked" in res.get_json()["error"].lower()


# ── Protected Profile Endpoint ────────────────────────────────────────────────

class TestProfile:
    def _get_token(self, client):
        client.post("/api/auth/register", json={
            "name": "Srinidhi", "email": "srinidhi@example.com", "password": "Secure@123"
        })
        res = client.post("/api/auth/login", json={
            "email": "srinidhi@example.com", "password": "Secure@123"
        })
        return res.get_json()["access_token"]

    def test_profile_with_valid_token(self, client):
        token = self._get_token(client)
        res = client.get("/api/auth/profile",
                         headers={"Authorization": f"Bearer {token}"})
        assert res.status_code == 200
        assert res.get_json()["email"] == "srinidhi@example.com"

    def test_profile_without_token_rejected(self, client):
        res = client.get("/api/auth/profile")
        assert res.status_code == 401

    def test_profile_with_fake_token_rejected(self, client):
        res = client.get("/api/auth/profile",
                         headers={"Authorization": "Bearer fake.token.here"})
        assert res.status_code == 422
