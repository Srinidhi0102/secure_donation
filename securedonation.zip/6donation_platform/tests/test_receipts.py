import pytest
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from app import create_app
from extensions import db as _db
from models import Receipt
from config import Config

class TestConfig(Config):
    TESTING                 = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    JWT_SECRET_KEY          = "test-jwt-key"
    AES_SECRET_KEY          = b"12345678901234567890123456789012"
    BCRYPT_LOG_ROUNDS       = 4
    FRAUD_MAX_AMOUNT        = 50000
    FRAUD_MAX_ATTEMPTS_PER_IP = 5
    FRAUD_WINDOW_MINUTES    = 10


@pytest.fixture(scope="function")
def app():
    app = create_app(TestConfig)
    with app.app_context():
        _db.create_all()
        yield app
        _db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def token(client):
    client.post("/api/auth/register", json={
        "name": "Receipt Tester", "email": "receipt@example.com", "password": "Secure@123"
    })
    res = client.post("/api/auth/login", json={
        "email": "receipt@example.com", "password": "Secure@123"
    })
    return res.get_json()["access_token"]


@pytest.fixture
def approved_donation_id(client, token):
    """Create a clean donation that will pass fraud checks."""
    res = client.post("/api/crypto/donate",
        headers={"Authorization": f"Bearer {token}"},
        json={"amount": 250, "cause": "Scholarship", "card_last4": "9999"})
    return res.get_json()["donation_id"]


# ── Generate receipt ──────────────────────────────────────────────────────────

class TestGenerateReceipt:
    def test_generate_receipt_success(self, client, token, approved_donation_id):
        res = client.post(f"/api/receipts/generate/{approved_donation_id}",
                          headers={"Authorization": f"Bearer {token}"})
        assert res.status_code == 201
        assert "receipt_id" in res.get_json()

    def test_receipt_is_encrypted_in_db(self, client, token, approved_donation_id, app):
        client.post(f"/api/receipts/generate/{approved_donation_id}",
                    headers={"Authorization": f"Bearer {token}"})
        with app.app_context():
            receipt = Receipt.query.filter_by(donation_id=approved_donation_id).first()
            assert receipt is not None
            # Encrypted blob must not contain readable text
            assert "Scholarship" not in receipt.encrypted_receipt
            assert "Receipt Tester" not in receipt.encrypted_receipt
            # Must have IV:ciphertext format
            assert ":" in receipt.encrypted_receipt
            # Must have SHA-256 hash stored (64 hex chars)
            assert len(receipt.receipt_hash) == 64

    def test_duplicate_generate_is_idempotent(self, client, token, approved_donation_id):
        client.post(f"/api/receipts/generate/{approved_donation_id}",
                    headers={"Authorization": f"Bearer {token}"})
        res = client.post(f"/api/receipts/generate/{approved_donation_id}",
                          headers={"Authorization": f"Bearer {token}"})
        assert res.status_code == 201   # no error on second call

    def test_generate_requires_auth(self, client, approved_donation_id):
        res = client.post(f"/api/receipts/generate/{approved_donation_id}")
        assert res.status_code == 401

    def test_generate_nonexistent_donation(self, client, token):
        res = client.post("/api/receipts/generate/999999",
                          headers={"Authorization": f"Bearer {token}"})
        assert res.status_code == 400


# ── Download receipt ──────────────────────────────────────────────────────────

class TestDownloadReceipt:
    def _fresh_donation(self, client, token, amount=300, cause="FreshCause"):
        res = client.post("/api/crypto/donate",
            headers={"Authorization": f"Bearer {token}"},
            json={"amount": amount, "cause": cause, "card_last4": "1111"})
        return res.get_json()["donation_id"]

    def test_download_returns_pdf(self, client, token):
        did = self._fresh_donation(client, token, 300, "PDFTest")
        client.post(f"/api/receipts/generate/{did}",
                    headers={"Authorization": f"Bearer {token}"})
        res = client.get(f"/api/receipts/download/{did}",
                         headers={"Authorization": f"Bearer {token}"})
        assert res.status_code == 200
        assert res.content_type == "application/pdf"
        assert res.data[:4] == b"%PDF"

    def test_download_without_generating_first(self, client, token):
        did = self._fresh_donation(client, token, 111, "NoReceipt")
        res = client.get(f"/api/receipts/download/{did}",
                         headers={"Authorization": f"Bearer {token}"})
        assert res.status_code == 400
        assert "Generate it first" in res.get_json()["error"]

    def test_tampered_receipt_rejected(self, client, token, app):
        did = self._fresh_donation(client, token, 400, "TamperTest")
        client.post(f"/api/receipts/generate/{did}",
                    headers={"Authorization": f"Bearer {token}"})
        with app.app_context():
            receipt = Receipt.query.filter_by(donation_id=did).first()
            assert receipt is not None
            receipt.receipt_hash = "b" * 64
            _db.session.commit()
        res = client.get(f"/api/receipts/download/{did}",
                         headers={"Authorization": f"Bearer {token}"})
        assert res.status_code == 400
        assert "tampered" in res.get_json()["error"]

    def test_download_requires_auth(self, client, token):
        did = self._fresh_donation(client, token, 500, "AuthTest")
        res = client.get(f"/api/receipts/download/{did}")
        assert res.status_code == 401
