import pytest
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from app import create_app
from extensions import db as _db
from models import Donation
from config import Config

class TestConfig(Config):
    TESTING                 = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    JWT_SECRET_KEY          = "test-jwt-key"
    AES_SECRET_KEY          = b"12345678901234567890123456789012"
    BCRYPT_LOG_ROUNDS       = 4
    MAX_LOGIN_ATTEMPTS      = 5


@pytest.fixture(scope="module")
def app():
    app = create_app(TestConfig)
    with app.app_context():
        _db.create_all()
        yield app
        _db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def auth_token(client):
    """Register a donor and return a valid JWT."""
    client.post("/api/auth/register", json={
        "name": "Crypto Tester", "email": "crypto@example.com", "password": "Secure@123"
    })
    res = client.post("/api/auth/login", json={
        "email": "crypto@example.com", "password": "Secure@123"
    })
    return res.get_json()["access_token"]


# ── Unit tests: AES primitives ────────────────────────────────────────────────

class TestAESPrimitives:
    def test_encrypt_returns_iv_and_ciphertext(self, app):
        with app.app_context():
            from crypto.aes import aes_encrypt
            token = aes_encrypt("hello")
            assert ":" in token
            iv_hex, ct_hex = token.split(":", 1)
            assert len(iv_hex) == 32   # 16 bytes → 32 hex chars
            assert len(ct_hex) > 0

    def test_decrypt_recovers_plaintext(self, app):
        with app.app_context():
            from crypto.aes import aes_encrypt, aes_decrypt
            original = "500.00"
            assert aes_decrypt(aes_encrypt(original)) == original

    def test_same_plaintext_gives_different_ciphertext(self, app):
        """Random IV means identical inputs produce different ciphertexts."""
        with app.app_context():
            from crypto.aes import aes_encrypt
            t1 = aes_encrypt("Education")
            t2 = aes_encrypt("Education")
            assert t1 != t2

    def test_encrypt_special_characters(self, app):
        with app.app_context():
            from crypto.aes import aes_encrypt, aes_decrypt
            text = "Flood Relief — ₹10,000 donation! <script>"
            assert aes_decrypt(aes_encrypt(text)) == text


# ── Unit tests: SHA-256 integrity hashing ────────────────────────────────────

class TestHashing:
    def test_hash_is_64_hex_chars(self, app):
        with app.app_context():
            from crypto.hashing import compute_transaction_hash
            h = compute_transaction_hash(1, "500", "Education", "1234", "2026-03-09T10:00:00")
            assert len(h) == 64
            assert all(c in "0123456789abcdef" for c in h)

    def test_same_inputs_produce_same_hash(self, app):
        with app.app_context():
            from crypto.hashing import compute_transaction_hash
            h1 = compute_transaction_hash(1, "500", "Education", "1234", "2026-03-09T10:00:00")
            h2 = compute_transaction_hash(1, "500", "Education", "1234", "2026-03-09T10:00:00")
            assert h1 == h2

    def test_changed_amount_breaks_hash(self, app):
        with app.app_context():
            from crypto.hashing import compute_transaction_hash
            h1 = compute_transaction_hash(1, "500",   "Education", "1234", "2026-03-09T10:00:00")
            h2 = compute_transaction_hash(1, "50000", "Education", "1234", "2026-03-09T10:00:00")
            assert h1 != h2

    def test_verify_returns_true_for_intact_record(self, app):
        with app.app_context():
            from crypto.hashing import compute_transaction_hash, verify_transaction_hash
            args = dict(donor_id=1, amount="500", cause="Health",
                        card_last4="9999", timestamp="2026-03-09T10:00:00")
            stored = compute_transaction_hash(**args)
            assert verify_transaction_hash(stored, **args) is True

    def test_verify_returns_false_for_tampered_record(self, app):
        with app.app_context():
            from crypto.hashing import compute_transaction_hash, verify_transaction_hash
            stored = compute_transaction_hash(1, "500", "Health", "9999", "2026-03-09T10:00:00")
            # Simulating DB tampering: amount changed from 500 → 99999
            assert verify_transaction_hash(stored, 1, "99999", "Health", "9999", "2026-03-09T10:00:00") is False


# ── Integration tests: /api/crypto endpoints ──────────────────────────────────

class TestDonateEndpoint:
    def test_donate_requires_auth(self, client):
        res = client.post("/api/crypto/donate", json={"amount": 500, "cause": "Food"})
        assert res.status_code == 401

    def test_successful_donation(self, client, auth_token):
        res = client.post("/api/crypto/donate",
                          headers={"Authorization": f"Bearer {auth_token}"},
                          json={"amount": 500, "cause": "Education", "card_last4": "1234"})
        assert res.status_code == 201
        assert "donation_id" in res.get_json()

    def test_donation_fields_are_encrypted_in_db(self, client, auth_token, app):
        """Raw amount must never appear as plaintext in the database."""
        res = client.post("/api/crypto/donate",
                          headers={"Authorization": f"Bearer {auth_token}"},
                          json={"amount": 77777, "cause": "WaterAid", "card_last4": "5678"})
        donation_id = res.get_json()["donation_id"]

        with app.app_context():
            donation = _db.session.get(Donation, donation_id)
            assert "77777" not in donation.encrypted_amount   # plaintext NOT in DB
            assert "WaterAid" not in donation.encrypted_cause
            assert "5678" not in donation.encrypted_card_last4

    def test_zero_amount_rejected(self, client, auth_token):
        res = client.post("/api/crypto/donate",
                          headers={"Authorization": f"Bearer {auth_token}"},
                          json={"amount": 0, "cause": "Education"})
        assert res.status_code == 400

    def test_missing_cause_rejected(self, client, auth_token):
        res = client.post("/api/crypto/donate",
                          headers={"Authorization": f"Bearer {auth_token}"},
                          json={"amount": 100})
        assert res.status_code == 400


class TestIntegrityEndpoint:
    @pytest.fixture
    def donation_id(self, client, auth_token):
        res = client.post("/api/crypto/donate",
                          headers={"Authorization": f"Bearer {auth_token}"},
                          json={"amount": 250, "cause": "Disaster Relief", "card_last4": "4321"})
        return res.get_json()["donation_id"]

    def test_verify_intact_donation(self, client, auth_token, donation_id):
        res = client.get(f"/api/crypto/verify/{donation_id}",
                         headers={"Authorization": f"Bearer {auth_token}"})
        assert res.status_code == 200
        assert res.get_json()["intact"] is True

    def test_verify_detects_tampering(self, client, auth_token, donation_id, app):
        """Directly corrupt the DB and confirm the integrity check catches it."""
        with app.app_context():
            donation = _db.session.get(Donation, donation_id)
            donation.integrity_hash = "a" * 64   # corrupt the stored hash
            _db.session.commit()

        res = client.get(f"/api/crypto/verify/{donation_id}",
                         headers={"Authorization": f"Bearer {auth_token}"})
        assert res.status_code == 409
        assert res.get_json()["intact"] is False

    def test_verify_nonexistent_donation(self, client, auth_token):
        res = client.get("/api/crypto/verify/999999",
                         headers={"Authorization": f"Bearer {auth_token}"})
        assert res.status_code == 404


class TestGetDonationEndpoint:
    def test_owner_can_view_decrypted_donation(self, client, auth_token):
        # Create
        res = client.post("/api/crypto/donate",
                          headers={"Authorization": f"Bearer {auth_token}"},
                          json={"amount": 1500, "cause": "Scholarship", "card_last4": "0000"})
        donation_id = res.get_json()["donation_id"]

        # Fetch decrypted
        res = client.get(f"/api/crypto/donation/{donation_id}",
                         headers={"Authorization": f"Bearer {auth_token}"})
        assert res.status_code == 200
        data = res.get_json()
        assert data["amount"]    == "1500.0"
        assert data["cause"]     == "Scholarship"
        assert data["card_last4"]== "0000"

    def test_other_donor_cannot_view_donation(self, client, app):
        """A second donor must not be able to read the first donor's decrypted record."""
        # Register second donor
        client.post("/api/auth/register", json={
            "name": "Other", "email": "other@example.com", "password": "Secure@123"
        })
        other_token = client.post("/api/auth/login", json={
            "email": "other@example.com", "password": "Secure@123"
        }).get_json()["access_token"]

        # Create donation as first donor
        first_token = client.post("/api/auth/login", json={
            "email": "crypto@example.com", "password": "Secure@123"
        }).get_json()["access_token"]
        res = client.post("/api/crypto/donate",
                          headers={"Authorization": f"Bearer {first_token}"},
                          json={"amount": 999, "cause": "Private"})
        donation_id = res.get_json()["donation_id"]

        # Second donor tries to access it
        res = client.get(f"/api/crypto/donation/{donation_id}",
                         headers={"Authorization": f"Bearer {other_token}"})
        assert res.status_code == 403
