import pytest
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from app import create_app
from extensions import db as _db
from models import Donation
from config import Config

class TestConfig(Config):
    TESTING                 = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    JWT_SECRET_KEY          = "test-jwt-key"
    AES_SECRET_KEY          = b"12345678901234567890123456789012"
    BCRYPT_LOG_ROUNDS       = 4
    FRAUD_MAX_AMOUNT        = 50000
    FRAUD_MAX_ATTEMPTS_PER_IP = 3
    FRAUD_WINDOW_MINUTES    = 10


@pytest.fixture(scope="module")
def app():
    app = create_app(TestConfig)
    with app.app_context():
        _db.create_all()
        yield app
        _db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def token(client):
    client.post("/api/auth/register", json={
        "name": "Fraud Tester", "email": "fraud@example.com", "password": "Secure@123"
    })
    res = client.post("/api/auth/login", json={
        "email": "fraud@example.com", "password": "Secure@123"
    })
    return res.get_json()["access_token"]


def donate(client, token, amount, cause="Education", card="1234"):
    return client.post("/api/crypto/donate",
        headers={"Authorization": f"Bearer {token}"},
        json={"amount": amount, "cause": cause, "card_last4": card})


# ── Rule 1: Amount threshold ──────────────────────────────────────────────────

class TestAmountThreshold:
    def test_normal_amount_approved(self, client, token):
        res = donate(client, token, 1000)
        assert res.status_code == 201
        assert res.get_json()["fraud_status"] == "approved"
        assert res.get_json()["fraud_flags"] == []

    def test_large_amount_flagged(self, client, token):
        res = donate(client, token, 99999)
        assert res.status_code == 201
        data = res.get_json()
        assert data["fraud_status"] == "flagged"
        assert any("threshold" in f for f in data["fraud_flags"])

    def test_exact_threshold_approved(self, client, token):
        res = donate(client, token, 50000)
        assert res.status_code == 201
        # 50000 is not > 50000 so amount rule alone won't trigger
        data = res.get_json()
        # round-number rule will trigger for 50000 — that's expected
        assert data["fraud_status"] in ("approved", "flagged")


# ── Rule 4: Round-number structuring ─────────────────────────────────────────

class TestRoundNumberRule:
    def test_round_number_above_50k_flagged(self, client, token):
        res = donate(client, token, 60000)
        data = res.get_json()
        assert data["fraud_status"] == "flagged"
        assert any("structuring" in f for f in data["fraud_flags"])

    def test_non_round_amount_not_flagged_by_this_rule(self, client, token):
        res = donate(client, token, 60001)
        data = res.get_json()
        # Only the amount-threshold rule fires, not structuring
        assert not any("structuring" in f for f in data["fraud_flags"])


# ── Fraud flags endpoint ──────────────────────────────────────────────────────

class TestFraudFlagsEndpoint:
    def test_flags_endpoint_returns_list(self, client, token):
        res = client.get("/api/fraud/flags",
                         headers={"Authorization": f"Bearer {token}"})
        assert res.status_code == 200
        data = res.get_json()
        assert "flags" in data
        assert "total" in data
        assert isinstance(data["flags"], list)

    def test_flags_endpoint_requires_auth(self, client):
        res = client.get("/api/fraud/flags")
        assert res.status_code == 401

    def test_flagged_donations_appear_in_list(self, client, token):
        donate(client, token, 99999)
        res = client.get("/api/fraud/flags",
                         headers={"Authorization": f"Bearer {token}"})
        data = res.get_json()
        assert data["total"] > 0
        assert all("reason" in f for f in data["flags"])
        assert all("donation_id" in f for f in data["flags"])
