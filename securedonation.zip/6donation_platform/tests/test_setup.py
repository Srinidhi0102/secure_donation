import pytest
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from app import create_app
from config import Config

class TestConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    JWT_SECRET_KEY = "test-jwt-key"
    AES_SECRET_KEY = b"12345678901234567890123456789012"


@pytest.fixture
def client():
    app = create_app(TestConfig)
    with app.test_client() as client:
        yield client


def test_register_endpoint_exists(client):
    res = client.post("/api/auth/register", json={})
    assert res.status_code == 400

def test_login_endpoint_exists(client):
    res = client.post("/api/auth/login", json={})
    assert res.status_code == 400

def test_donate_endpoint_exists(client):
    res = client.post("/api/crypto/donate", json={})
    assert res.status_code == 401  # now requires JWT

def test_fraud_check_endpoint_exists(client):
    res = client.post("/api/fraud/check/1")
    assert res.status_code == 401  # now requires JWT

def test_receipt_generate_endpoint_exists(client):
    res = client.post("/api/receipts/generate/1")
    assert res.status_code == 401  # now requires JWT
