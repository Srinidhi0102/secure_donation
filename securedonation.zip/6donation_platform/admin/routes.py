from flask import Blueprint, jsonify, request
from auth.service import admin_required
from extensions import db
from models import Donor, Donation, FraudFlag, AuditLog, Receipt
from crypto.aes import aes_decrypt

admin_bp = Blueprint("admin", __name__)


# ── GET /api/admin/stats ──────────────────────────────────────────────────────
@admin_bp.route("/stats", methods=["GET"])
@admin_required
def stats():
    """Platform-wide summary numbers."""
    total_donors    = Donor.query.filter_by(is_admin=False).count()
    total_donations = Donation.query.count()
    flagged         = Donation.query.filter_by(status="flagged").count()
    approved        = Donation.query.filter_by(status="approved").count()
    pending         = Donation.query.filter_by(status="pending").count()
    total_flags     = FraudFlag.query.count()
    total_receipts  = Receipt.query.count()
    total_logs      = AuditLog.query.count()

    # Decrypt all amounts to sum total volume
    all_donations = Donation.query.all()
    total_volume  = 0.0
    for d in all_donations:
        try:
            total_volume += float(aes_decrypt(d.encrypted_amount))
        except Exception:
            pass

    return jsonify({
        "donors":         total_donors,
        "donations":      total_donations,
        "approved":       approved,
        "flagged":        flagged,
        "pending":        pending,
        "fraud_flags":    total_flags,
        "receipts":       total_receipts,
        "audit_logs":     total_logs,
        "total_volume":   round(total_volume, 2),
    }), 200


# ── GET /api/admin/donors ─────────────────────────────────────────────────────
@admin_bp.route("/donors", methods=["GET"])
@admin_required
def list_donors():
    """All registered donors."""
    donors = Donor.query.filter_by(is_admin=False).order_by(Donor.created_at.desc()).all()
    return jsonify([{
        "id":             d.id,
        "name":           d.name,
        "email":          d.email,
        "is_active":      d.is_active,
        "login_attempts": d.login_attempts,
        "locked_until":   d.locked_until.isoformat() if d.locked_until else None,
        "created_at":     d.created_at.isoformat(),
    } for d in donors]), 200


# ── GET /api/admin/donations ──────────────────────────────────────────────────
@admin_bp.route("/donations", methods=["GET"])
@admin_required
def list_donations():
    """All donations — decrypted for admin view."""
    donations = Donation.query.order_by(Donation.created_at.desc()).limit(100).all()
    result = []
    for d in donations:
        try:
            amount     = aes_decrypt(d.encrypted_amount)
            cause      = aes_decrypt(d.encrypted_cause)
            card_last4 = aes_decrypt(d.encrypted_card_last4)
        except Exception:
            amount = cause = card_last4 = "[decrypt error]"
        result.append({
            "id":         d.id,
            "donor_id":   d.donor_id,
            "amount":     amount,
            "cause":      cause,
            "card_last4": card_last4,
            "status":     d.status,
            "donor_ip":   d.donor_ip,
            "created_at": d.created_at.isoformat(),
        })
    return jsonify(result), 200


# ── GET /api/admin/flags ──────────────────────────────────────────────────────
@admin_bp.route("/flags", methods=["GET"])
@admin_required
def list_flags():
    """All fraud flags."""
    flags = FraudFlag.query.order_by(FraudFlag.flagged_at.desc()).all()
    return jsonify([{
        "id":          f.id,
        "donation_id": f.donation_id,
        "reason":      f.reason,
        "flagged_at":  f.flagged_at.isoformat(),
    } for f in flags]), 200


# ── GET /api/admin/logs ───────────────────────────────────────────────────────
@admin_bp.route("/logs", methods=["GET"])
@admin_required
def audit_logs():
    """Full audit trail — last 200 events."""
    logs = AuditLog.query.order_by(AuditLog.timestamp.desc()).limit(200).all()
    return jsonify([{
        "id":         l.id,
        "event":      l.event_type,
        "user_id":    l.user_id,
        "ip":         l.ip_address,
        "details":    l.details,
        "timestamp":  l.timestamp.isoformat(),
    } for l in logs]), 200


# ── POST /api/admin/donors/<id>/unlock ───────────────────────────────────────
@admin_bp.route("/donors/<int:donor_id>/unlock", methods=["POST"])
@admin_required
def unlock_donor(donor_id):
    """Manually unlock a locked-out donor account."""
    donor = db.session.get(Donor, donor_id)
    if not donor:
        return jsonify({"error": "Donor not found"}), 404
    donor.locked_until    = None
    donor.login_attempts  = 0
    db.session.commit()
    return jsonify({"message": f"Donor {donor_id} unlocked successfully"}), 200


# ── POST /api/admin/donors/<id>/deactivate ───────────────────────────────────
@admin_bp.route("/donors/<int:donor_id>/deactivate", methods=["POST"])
@admin_required
def deactivate_donor(donor_id):
    """Deactivate a donor account."""
    donor = db.session.get(Donor, donor_id)
    if not donor:
        return jsonify({"error": "Donor not found"}), 404
    donor.is_active = False
    db.session.commit()
    return jsonify({"message": f"Donor {donor_id} deactivated"}), 200
