from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from fraud.service import check_and_flag, get_all_flags

fraud_bp = Blueprint("fraud", __name__)


# ── POST /api/fraud/check/<id> ────────────────────────────────────────────────
@fraud_bp.route("/check/<int:donation_id>", methods=["POST"])
@jwt_required()
def check_fraud(donation_id):
    """
    Run all fraud rules against a donation.
    Called automatically after every donation is created.
    """
    result = check_and_flag(donation_id)
    if not result["success"]:
        return jsonify({"error": result["error"]}), 404

    status_code = 200 if result["status"] == "approved" else 422
    return jsonify(result), status_code


# ── GET /api/fraud/flags ──────────────────────────────────────────────────────
@fraud_bp.route("/flags", methods=["GET"])
@jwt_required()
def list_flags():
    """Return all fraud-flagged donations."""
    flags = get_all_flags()
    return jsonify({"total": len(flags), "flags": flags}), 200
