"""
Rule-based fraud detection (CO3 — Fraud Prevention).

Rules applied to every donation before it is approved:

  Rule 1 — Amount threshold
    Donations above FRAUD_MAX_AMOUNT are flagged as unusually large.

  Rule 2 — IP velocity
    More than FRAUD_MAX_ATTEMPTS_PER_IP donations from the same IP
    within FRAUD_WINDOW_MINUTES minutes triggers a flag.

  Rule 3 — Rapid repeat donations
    The same donor submitting more than 3 donations within 5 minutes
    is flagged for unusual velocity.

  Rule 4 — Round-number structuring
    Donations that are exact large round numbers (multiples of 10 000)
    above 50 000 are flagged — a pattern associated with structuring fraud.

Each triggered rule creates a FraudFlag record and sets the donation
status to "flagged". Clean donations are set to "approved".
"""

from datetime import datetime, timezone, timedelta
from flask import current_app
from extensions import db
from models import Donation, FraudFlag, AuditLog


def _utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


# ── Main entry point ──────────────────────────────────────────────────────────

def check_and_flag(donation_id: int) -> dict:
    """
    Run all fraud rules against a donation.
    Updates donation.status to 'approved' or 'flagged'.
    Returns a summary dict.
    """
    donation = db.session.get(Donation, donation_id)
    if not donation:
        return {"success": False, "error": "Donation not found"}

    # Decrypt amount for rule evaluation
    from crypto.aes import aes_decrypt
    try:
        amount = float(aes_decrypt(donation.encrypted_amount))
    except Exception:
        return {"success": False, "error": "Could not decrypt donation amount"}

    flags = []

    # ── Rule 1: Amount threshold ──────────────────────────────────────────────
    max_amount = current_app.config["FRAUD_MAX_AMOUNT"]
    if amount > max_amount:
        flags.append(f"Amount ₹{amount:,.0f} exceeds threshold ₹{max_amount:,}")

    # ── Rule 2: IP velocity ───────────────────────────────────────────────────
    if donation.donor_ip:
        window_mins  = current_app.config["FRAUD_WINDOW_MINUTES"]
        max_per_ip   = current_app.config["FRAUD_MAX_ATTEMPTS_PER_IP"]
        window_start = _utcnow() - timedelta(minutes=window_mins)

        ip_count = Donation.query.filter(
            Donation.donor_ip  == donation.donor_ip,
            Donation.created_at >= window_start,
            Donation.id        != donation.id
        ).count()

        if ip_count >= max_per_ip:
            flags.append(
                f"IP {donation.donor_ip} made {ip_count + 1} donations "
                f"within {window_mins} minutes"
            )

    # ── Rule 3: Rapid repeat by same donor ───────────────────────────────────
    rapid_window = _utcnow() - timedelta(minutes=5)
    repeat_count = Donation.query.filter(
        Donation.donor_id  == donation.donor_id,
        Donation.created_at >= rapid_window,
        Donation.id        != donation.id
    ).count()

    if repeat_count >= 3:
        flags.append(
            f"Donor {donation.donor_id} submitted {repeat_count + 1} "
            f"donations within 5 minutes"
        )

    # ── Rule 4: Round-number structuring ─────────────────────────────────────
    if amount >= 50_000 and amount % 10_000 == 0:
        flags.append(
            f"Suspicious round-number amount ₹{amount:,.0f} "
            f"(possible structuring)"
        )

    # ── Persist flags & update status ────────────────────────────────────────
    if flags:
        donation.status = "flagged"
        for reason in flags:
            db.session.add(FraudFlag(
                donation_id = donation.id,
                reason      = reason,
                flagged_at  = _utcnow()
            ))
        _log("FRAUD_FLAGGED", user_id=donation.donor_id,
             details=f"Donation {donation_id} flagged: {'; '.join(flags)}")
    else:
        donation.status = "approved"
        _log("FRAUD_CLEAR", user_id=donation.donor_id,
             details=f"Donation {donation_id} passed all fraud checks")

    db.session.commit()

    return {
        "success":     True,
        "donation_id": donation_id,
        "status":      donation.status,
        "flags":       flags,
        "message":     f"{len(flags)} fraud rule(s) triggered" if flags
                       else "All fraud checks passed"
    }


def get_all_flags() -> list:
    """Return all flagged donations with their reasons (for admin review)."""
    flags = FraudFlag.query.order_by(FraudFlag.flagged_at.desc()).all()
    return [
        {
            "flag_id":     f.id,
            "donation_id": f.donation_id,
            "reason":      f.reason,
            "flagged_at":  f.flagged_at.isoformat()
        }
        for f in flags
    ]


def _log(event_type, user_id=None, details=None):
    db.session.add(AuditLog(
        event_type=event_type, user_id=user_id, details=details
    ))
    db.session.commit()
