from flask import Blueprint, jsonify, send_file
from flask_jwt_extended import jwt_required, get_jwt_identity
from receipts.service import generate_receipt, download_receipt
import io

receipts_bp = Blueprint("receipts", __name__)


# ── POST /api/receipts/generate/<id> ─────────────────────────────────────────
@receipts_bp.route("/generate/<int:donation_id>", methods=["POST"])
@jwt_required()
def gen_receipt(donation_id):
    donor_id = int(get_jwt_identity())
    result   = generate_receipt(donation_id, donor_id)

    if not result["success"]:
        return jsonify({"error": result["error"]}), 400

    return jsonify({
        "message":    "Receipt generated and encrypted successfully",
        "receipt_id": result["receipt_id"],
    }), 201


# ── GET /api/receipts/download/<id> ──────────────────────────────────────────
@receipts_bp.route("/download/<int:donation_id>", methods=["GET"])
@jwt_required()
def dl_receipt(donation_id):
    donor_id = int(get_jwt_identity())
    result   = download_receipt(donation_id, donor_id)

    if not result["success"]:
        return jsonify({"error": result["error"]}), 400

    return send_file(
        io.BytesIO(result["pdf_bytes"]),
        mimetype="application/pdf",
        as_attachment=True,
        download_name=f"receipt_donation_{donation_id}.pdf"
    )
