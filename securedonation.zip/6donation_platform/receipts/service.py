"""
Encrypted receipt generation (CO4 — Non-repudiation).

Flow:
  1. Build a plain-text receipt string from the decrypted donation data.
  2. Use reportlab to render it as a PDF (in memory — never touches disk).
  3. AES-256-CBC encrypt the raw PDF bytes → hex string stored in DB.
  4. SHA-256 hash the encrypted blob → stored as receipt_hash for integrity.
  5. On download: decrypt the blob, return the PDF bytes to the donor.

Why encrypt the PDF?
  The receipt contains the donor's name, amount, and cause. Storing it
  encrypted means a DB breach exposes no readable receipt content.
  The SHA-256 hash of the encrypted blob proves the receipt was not
  modified after generation (non-repudiation).
"""

import io
from datetime import datetime, timezone
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.pdfgen import canvas

from extensions import db
from models import Donation, Donor, Receipt
from crypto.aes import aes_encrypt, aes_decrypt
from crypto.hashing import compute_generic_hash
from crypto.service import get_donation_decrypted


def _utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


# ── Generate Receipt ──────────────────────────────────────────────────────────

def generate_receipt(donation_id: int, donor_id: int) -> dict:
    """
    Generate, encrypt, and store a donation receipt PDF.
    Returns {"success": True, "receipt_id": ...} or error dict.
    """
    # Check receipt doesn't already exist
    existing = Receipt.query.filter_by(donation_id=donation_id).first()
    if existing:
        return {"success": True, "receipt_id": existing.id, "already_exists": True}

    # Load and decrypt donation data
    data = get_donation_decrypted(donation_id, donor_id)
    if not data["success"]:
        return {"success": False, "error": data["error"]}

    if data["status"] == "flagged":
        return {"success": False, "error": "Cannot generate receipt for a flagged donation"}

    donor = db.session.get(Donor, donor_id)
    if not donor:
        return {"success": False, "error": "Donor not found"}

    # Build PDF in memory
    pdf_bytes = _build_pdf(
        donor_name  = donor.name,
        donor_email = donor.email,
        amount      = data["amount"],
        cause       = data["cause"],
        card_last4  = data["card_last4"],
        donation_id = donation_id,
        created_at  = data["created_at"],
    )

    # AES-encrypt the PDF bytes (convert bytes → hex for storage)
    from flask import current_app
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad
    import os

    key = current_app.config["AES_SECRET_KEY"]
    if isinstance(key, str):
        key = key.encode()
    iv         = os.urandom(16)
    cipher     = AES.new(key, AES.MODE_CBC, iv)
    padded     = pad(pdf_bytes, AES.block_size)
    encrypted  = cipher.encrypt(padded)
    enc_hex    = iv.hex() + ":" + encrypted.hex()

    # SHA-256 hash of the encrypted blob (proves receipt wasn't modified)
    receipt_hash = compute_generic_hash(enc_hex)

    receipt = Receipt(
        donation_id       = donation_id,
        encrypted_receipt = enc_hex,
        receipt_hash      = receipt_hash,
        generated_at      = _utcnow(),
    )
    db.session.add(receipt)
    db.session.commit()

    return {"success": True, "receipt_id": receipt.id}


# ── Download Receipt ──────────────────────────────────────────────────────────

def download_receipt(donation_id: int, donor_id: int) -> dict:
    """
    Verify receipt integrity, decrypt, and return raw PDF bytes.
    """
    receipt = Receipt.query.filter_by(donation_id=donation_id).first()
    if not receipt:
        return {"success": False, "error": "Receipt not found. Generate it first."}

    # Verify integrity before decrypting
    current_hash = compute_generic_hash(receipt.encrypted_receipt)
    if current_hash != receipt.receipt_hash:
        return {"success": False,
                "error": "Receipt integrity check failed — file may have been tampered with"}

    # Decrypt PDF bytes
    from flask import current_app
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import unpad

    key = current_app.config["AES_SECRET_KEY"]
    if isinstance(key, str):
        key = key.encode()

    iv_hex, ct_hex = receipt.encrypted_receipt.split(":", 1)
    iv         = bytes.fromhex(iv_hex)
    ciphertext = bytes.fromhex(ct_hex)
    cipher     = AES.new(key, AES.MODE_CBC, iv)
    padded     = cipher.decrypt(ciphertext)
    pdf_bytes  = unpad(padded, AES.block_size)

    return {"success": True, "pdf_bytes": pdf_bytes}


# ── PDF Builder ───────────────────────────────────────────────────────────────

def _build_pdf(donor_name, donor_email, amount, cause,
               card_last4, donation_id, created_at) -> bytes:
    """Render a donation receipt as a PDF and return raw bytes."""
    buf    = io.BytesIO()
    c      = canvas.Canvas(buf, pagesize=A4)
    W, H   = A4

    # Header bar
    c.setFillColorRGB(0.20, 0.29, 0.72)
    c.rect(0, H - 90, W, 90, fill=1, stroke=0)
    c.setFillColorRGB(1, 1, 1)
    c.setFont("Helvetica-Bold", 22)
    c.drawCentredString(W / 2, H - 45, "Secure Online Donation Platform")
    c.setFont("Helvetica", 12)
    c.drawCentredString(W / 2, H - 68, "Official Donation Receipt")

    # Receipt body
    c.setFillColorRGB(0.1, 0.1, 0.1)
    y = H - 130

    def row(label, value, bold=False):
        nonlocal y
        c.setFont("Helvetica-Bold" if bold else "Helvetica", 11)
        c.setFillColorRGB(0.4, 0.4, 0.4)
        c.drawString(2 * cm, y, label)
        c.setFont("Helvetica-Bold" if bold else "Helvetica", 11)
        c.setFillColorRGB(0.1, 0.1, 0.1)
        c.drawString(7 * cm, y, str(value))
        y -= 28

    row("Receipt No.",  f"RCP-{donation_id:06d}")
    row("Date",         created_at[:10])
    y -= 10

    row("Donor Name",  donor_name,  bold=True)
    row("Email",        donor_email)
    y -= 10

    row("Cause",        cause,       bold=True)
    row("Amount",       f"Rs. {float(amount):,.2f}", bold=True)
    if card_last4:
        row("Card",     f"**** **** **** {card_last4}")
    y -= 10

    row("Status",       "CONFIRMED")

    # Divider
    y -= 10
    c.setStrokeColorRGB(0.8, 0.8, 0.8)
    c.line(2 * cm, y, W - 2 * cm, y)
    y -= 20

    # Security note
    c.setFont("Helvetica-Oblique", 9)
    c.setFillColorRGB(0.5, 0.5, 0.5)
    c.drawString(2 * cm, y,
        "This receipt is cryptographically secured. "
        "SHA-256 integrity hash stored on server.")
    y -= 14
    c.drawString(2 * cm, y,
        "Shah & Anchor Kutchhi Engineering College — CSS Mini Project, 2026")

    c.save()
    return buf.getvalue()
