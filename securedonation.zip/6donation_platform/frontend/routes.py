from flask import Blueprint, render_template

frontend_bp = Blueprint("frontend", __name__)

@frontend_bp.route("/")
def index():
    return render_template("index.html")

@frontend_bp.route("/register")
def register():
    return render_template("auth.html", mode="register")

@frontend_bp.route("/login")
def login():
    return render_template("auth.html", mode="login")

@frontend_bp.route("/donate")
def donate():
    return render_template("donate.html")

@frontend_bp.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

@frontend_bp.route("/admin")
def admin():
    return render_template("admin.html")
