"""
SHA-256 integrity hashing (CO2 — Data Integrity).

How it works:
  1. Before a donation is saved, a canonical string is built from its raw fields:
       "<donor_id>|<amount>|<cause>|<card_last4>|<timestamp>"
  2. SHA-256 hashes that string → a 64-char hex digest stored alongside the record.
  3. To verify later: rebuild the same canonical string, re-hash it, compare to stored hash.
     Any tampering (even a single character change in the DB) produces a different digest.

Why store the hash separately from the encrypted fields?
  The encrypted fields protect *confidentiality*.
  The hash protects *integrity* — it lets us detect if someone modifies the encrypted
  blobs directly in the database, bypassing the application layer.
"""

import hashlib


def compute_transaction_hash(
    donor_id:   int,
    amount:     str,
    cause:      str,
    card_last4: str,
    timestamp:  str,
) -> str:
    """
    Compute a SHA-256 digest over the raw (unencrypted) transaction fields.
    Returns a 64-character lowercase hex string.
    """
    canonical = f"{donor_id}|{amount}|{cause}|{card_last4}|{timestamp}"
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def verify_transaction_hash(
    stored_hash: str,
    donor_id:    int,
    amount:      str,
    cause:       str,
    card_last4:  str,
    timestamp:   str,
) -> bool:
    """
    Re-compute the hash and compare it to the stored value.
    Returns True if the record is untampered, False if integrity has been violated.
    """
    expected = compute_transaction_hash(
        donor_id=donor_id,
        amount=amount,
        cause=cause,
        card_last4=card_last4,
        timestamp=timestamp,
    )
    return expected == stored_hash


def compute_generic_hash(data: str) -> str:
    """SHA-256 hash for any arbitrary string (used for receipt hashing)."""
    return hashlib.sha256(data.encode("utf-8")).hexdigest()
