"""
AES-256-CBC encryption helpers (CO2 — Confidentiality).

How it works:
  1. A random 16-byte IV is generated for every encryption call.
  2. The plaintext is PKCS7-padded to a 16-byte block boundary.
  3. AES-256-CBC encrypts the padded plaintext using the app's 32-byte key + IV.
  4. The result is stored as  hex(IV) + ":" + hex(ciphertext)  — one string in the DB.
  5. Decryption splits on ":", recovers IV and ciphertext, then reverses the process.

Why CBC + random IV?
  The same plaintext (e.g. amount "500") produces a *different* ciphertext every time,
  so an attacker who sees the database cannot detect repeated values.
"""

import os
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from flask import current_app


def _get_key() -> bytes:
    key = current_app.config["AES_SECRET_KEY"]
    if isinstance(key, str):
        key = key.encode()
    if len(key) != 32:
        raise ValueError("AES_SECRET_KEY must be exactly 32 bytes for AES-256")
    return key


def aes_encrypt(plaintext: str) -> str:
    """
    Encrypt a plaintext string.
    Returns a hex string formatted as  '<iv_hex>:<ciphertext_hex>'
    """
    key = _get_key()
    iv  = os.urandom(16)                              # fresh random IV every call
    cipher = AES.new(key, AES.MODE_CBC, iv)
    padded = pad(plaintext.encode("utf-8"), AES.block_size)
    ciphertext = cipher.encrypt(padded)
    return iv.hex() + ":" + ciphertext.hex()


def aes_decrypt(token: str) -> str:
    """
    Decrypt a token produced by aes_encrypt().
    Returns the original plaintext string.
    """
    key = _get_key()
    iv_hex, ct_hex = token.split(":", 1)
    iv         = bytes.fromhex(iv_hex)
    ciphertext = bytes.fromhex(ct_hex)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    padded = cipher.decrypt(ciphertext)
    return unpad(padded, AES.block_size).decode("utf-8")
