"""
Donation transaction service (CO2).

Flow for a new donation:
  1. Validate inputs.
  2. Compute SHA-256 hash over raw plaintext fields (integrity baseline).
  3. AES-256-CBC encrypt each sensitive field individually.
  4. Store only the encrypted blobs + hash in the DB — plaintext never persists.
  5. Return the donation ID to the caller.

Flow for integrity verification:
  1. Load the Donation record.
  2. AES-decrypt each encrypted field back to plaintext.
  3. Re-compute SHA-256 over the decrypted values + stored timestamp.
  4. Compare against the stored hash — mismatch means the record was tampered with.
"""

from datetime import datetime, timezone
from models import Donation, AuditLog
from extensions import db
from crypto.aes import aes_encrypt, aes_decrypt
from crypto.hashing import compute_transaction_hash, verify_transaction_hash


def _utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


# ── Create Donation ───────────────────────────────────────────────────────────

def create_donation(
    donor_id:   int,
    amount:     float,
    cause:      str,
    card_last4: str,
    donor_ip:   str = None,
) -> dict:
    """
    Encrypt and store a donation transaction.
    Returns {"success": True, "donation_id": ...} or {"success": False, "error": ...}
    """
    if amount <= 0:
        return {"success": False, "error": "Donation amount must be greater than zero"}
    if not cause or not cause.strip():
        return {"success": False, "error": "Cause is required"}
    if card_last4 and (not card_last4.isdigit() or len(card_last4) != 4):
        return {"success": False, "error": "card_last4 must be exactly 4 digits"}

    timestamp = _utcnow().isoformat()

    # Step 1 — integrity hash over raw plaintext (before encryption)
    integrity_hash = compute_transaction_hash(
        donor_id=donor_id,
        amount=str(amount),
        cause=cause.strip(),
        card_last4=card_last4 or "",
        timestamp=timestamp,
    )

    # Step 2 — AES-256-CBC encrypt each sensitive field
    encrypted_amount     = aes_encrypt(str(amount))
    encrypted_cause      = aes_encrypt(cause.strip())
    encrypted_card_last4 = aes_encrypt(card_last4) if card_last4 else aes_encrypt("")

    # Step 3 — persist only the encrypted blobs + hash
    donation = Donation(
        donor_id             = donor_id,
        encrypted_amount     = encrypted_amount,
        encrypted_cause      = encrypted_cause,
        encrypted_card_last4 = encrypted_card_last4,
        integrity_hash       = integrity_hash,
        donor_ip             = donor_ip,
        status               = "pending",
        created_at           = datetime.fromisoformat(timestamp),
    )
    db.session.add(donation)
    db.session.commit()

    _log("DONATION_CREATED", user_id=donor_id, ip=donor_ip,
         details=f"Donation {donation.id} created (encrypted)")
    return {"success": True, "donation_id": donation.id}


# ── Verify Integrity ──────────────────────────────────────────────────────────

def verify_donation_integrity(donation_id: int) -> dict:
    """
    Decrypt the stored fields, recompute the SHA-256 hash, compare to stored hash.
    Returns a dict with 'intact' bool and human-readable 'message'.
    """
    donation = db.session.get(Donation, donation_id)
    if not donation:
        return {"success": False, "error": "Donation not found"}

    # Decrypt fields back to plaintext
    try:
        amount     = aes_decrypt(donation.encrypted_amount)
        cause      = aes_decrypt(donation.encrypted_cause)
        card_last4 = aes_decrypt(donation.encrypted_card_last4)
    except Exception as e:
        return {"success": False, "error": f"Decryption failed: {str(e)}"}

    timestamp = donation.created_at.isoformat()

    intact = verify_transaction_hash(
        stored_hash = donation.integrity_hash,
        donor_id    = donation.donor_id,
        amount      = amount,
        cause       = cause,
        card_last4  = card_last4,
        timestamp   = timestamp,
    )

    _log("INTEGRITY_CHECK", user_id=donation.donor_id,
         details=f"Donation {donation_id}: {'INTACT' if intact else 'TAMPERED'}")

    return {
        "success":     True,
        "donation_id": donation_id,
        "intact":      intact,
        "message":     "Record integrity verified — data is untampered." if intact
                       else "WARNING: Integrity hash mismatch — record may have been tampered with!",
    }


# ── Get Donation (decrypted, for authorised viewing) ──────────────────────────

def get_donation_decrypted(donation_id: int, requesting_donor_id: int) -> dict:
    """
    Return decrypted donation details. Only the owning donor may view their record.
    """
    donation = db.session.get(Donation, donation_id)
    if not donation:
        return {"success": False, "error": "Donation not found"}
    if donation.donor_id != requesting_donor_id:
        return {"success": False, "error": "Access denied"}

    try:
        amount     = aes_decrypt(donation.encrypted_amount)
        cause      = aes_decrypt(donation.encrypted_cause)
        card_last4 = aes_decrypt(donation.encrypted_card_last4)
    except Exception as e:
        return {"success": False, "error": f"Decryption failed: {str(e)}"}

    return {
        "success":     True,
        "donation_id": donation.id,
        "amount":      amount,
        "cause":       cause,
        "card_last4":  card_last4,
        "status":      donation.status,
        "created_at":  donation.created_at.isoformat(),
    }


# ── Internal ──────────────────────────────────────────────────────────────────

def _log(event_type, user_id=None, ip=None, details=None):
    db.session.add(AuditLog(
        event_type=event_type, user_id=user_id,
        ip_address=ip, details=details
    ))
    db.session.commit()
