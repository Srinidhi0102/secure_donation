from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from crypto.service import create_donation, verify_donation_integrity, get_donation_decrypted
from fraud.service import check_and_flag

crypto_bp = Blueprint("crypto", __name__)


@crypto_bp.route("/donate", methods=["POST"])
@jwt_required()
def donate():
    donor_id = int(get_jwt_identity())
    data     = request.get_json(silent=True) or {}

    amount     = data.get("amount")
    cause      = data.get("cause", "").strip()
    card_last4 = data.get("card_last4", "").strip()

    if amount is None or not cause:
        return jsonify({"error": "amount and cause are required"}), 400

    try:
        amount = float(amount)
    except (ValueError, TypeError):
        return jsonify({"error": "amount must be a number"}), 400

    result = create_donation(
        donor_id=donor_id, amount=amount,
        cause=cause, card_last4=card_last4 or None,
        donor_ip=request.remote_addr,
    )
    if not result["success"]:
        return jsonify({"error": result["error"]}), 400

    donation_id = result["donation_id"]

    # ── Auto-run fraud check on every donation ────────────────────────────────
    fraud_result = check_and_flag(donation_id)
    fraud_status = fraud_result.get("status", "unknown")
    fraud_flags  = fraud_result.get("flags", [])

    return jsonify({
        "message":      "Donation received and encrypted successfully",
        "donation_id":  donation_id,
        "fraud_status": fraud_status,
        "fraud_flags":  fraud_flags,
    }), 201


@crypto_bp.route("/verify/<int:donation_id>", methods=["GET"])
@jwt_required()
def verify_integrity(donation_id):
    result = verify_donation_integrity(donation_id)
    if not result["success"]:
        return jsonify({"error": result["error"]}), 404
    return jsonify(result), 200 if result["intact"] else 409


@crypto_bp.route("/donation/<int:donation_id>", methods=["GET"])
@jwt_required()
def get_donation(donation_id):
    donor_id = int(get_jwt_identity())
    result   = get_donation_decrypted(donation_id, donor_id)
    if not result["success"]:
        code = 403 if "Access denied" in result.get("error", "") else 404
        return jsonify({"error": result["error"]}), code
    return jsonify(result), 200
