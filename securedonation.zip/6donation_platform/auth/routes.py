from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from auth.service import register_donor, login_donor, validate_password_strength, get_donor_by_id

auth_bp = Blueprint("auth", __name__)


# ── POST /api/auth/register ───────────────────────────────────────────────────
@auth_bp.route("/register", methods=["POST"])
def register():
    """
    Register a new donor.
    Body: { "name": "Harshit Jain", "email": "h@example.com", "password": "Secure@123" }
    """
    data = request.get_json(silent=True) or {}

    name     = data.get("name",     "").strip()
    email    = data.get("email",    "").strip()
    password = data.get("password", "")

    # ── Input validation ─────────────────────────────
    if not name or not email or not password:
        return jsonify({"error": "name, email, and password are required"}), 400

    if "@" not in email or "." not in email:
        return jsonify({"error": "Invalid email format"}), 400

    strength = validate_password_strength(password)
    if not strength["valid"]:
        return jsonify({"error": strength["error"]}), 400

    # ── Register (bcrypt hashing happens inside service) ──
    result = register_donor(name=name, email=email, password=password)
    if not result["success"]:
        return jsonify({"error": result["error"]}), 409

    return jsonify({
        "message":  "Registration successful",
        "donor_id": result["donor_id"]
    }), 201


# ── POST /api/auth/login ──────────────────────────────────────────────────────
@auth_bp.route("/login", methods=["POST"])
def login():
    """
    Login and receive a JWT.
    Body: { "email": "h@example.com", "password": "Secure@123" }
    """
    data = request.get_json(silent=True) or {}

    email    = data.get("email",    "").strip()
    password = data.get("password", "")
    ip       = request.remote_addr

    if not email or not password:
        return jsonify({"error": "email and password are required"}), 400

    result = login_donor(email=email, password=password, ip_address=ip)

    if not result["success"]:
        return jsonify({"error": result["error"]}), 401

    return jsonify({
        "message":      "Login successful",
        "access_token": result["access_token"],
        "donor_id":     result["donor_id"],
        "name":         result["name"],
        "is_admin":     result.get("is_admin", False)
    }), 200


# ── GET /api/auth/profile ─────────────────────────────────────────────────────
@auth_bp.route("/profile", methods=["GET"])
@jwt_required()
def profile():
    """
    Get current donor profile. Requires valid JWT in Authorization header.
    Header: Authorization: Bearer <token>
    """
    donor_id = int(get_jwt_identity())
    donor    = get_donor_by_id(donor_id)

    if not donor:
        return jsonify({"error": "Donor not found"}), 404

    return jsonify({
        "donor_id":   donor.id,
        "name":       donor.name,
        "email":      donor.email,
        "created_at": donor.created_at.isoformat()
    }), 200


# ── POST /api/auth/logout ─────────────────────────────────────────────────────
@auth_bp.route("/logout", methods=["POST"])
@jwt_required()
def logout():
    """
    Logout the current donor.
    Note: For full JWT blacklisting, add flask-jwt-extended blocklist in Phase 2.
    """
    donor_id = get_jwt_identity()
    return jsonify({
        "message": f"Donor {donor_id} logged out successfully"
    }), 200
