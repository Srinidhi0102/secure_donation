from datetime import datetime, timedelta, timezone

def _utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)
from flask import current_app
from flask_jwt_extended import create_access_token
from extensions import db, bcrypt
from models import Donor, AuditLog


# ── Registration ──────────────────────────────────────────────────────────────

def register_donor(name: str, email: str, password: str) -> dict:
    """
    Hash password with bcrypt and create a new Donor.
    Returns {"success": True, "donor_id": ...} or {"success": False, "error": ...}
    """
    if Donor.query.filter_by(email=email.lower()).first():
        return {"success": False, "error": "Email already registered"}

    # bcrypt automatically generates a random salt and hashes
    password_hash = bcrypt.generate_password_hash(
        password,
        rounds=current_app.config["BCRYPT_LOG_ROUNDS"]
    ).decode("utf-8")

    donor = Donor(
        name          = name.strip(),
        email         = email.lower().strip(),
        password_hash = password_hash
    )
    db.session.add(donor)
    db.session.commit()

    _log(event_type="REGISTER", user_id=donor.id, details=f"New donor registered: {email}")
    return {"success": True, "donor_id": donor.id}


# ── Login ─────────────────────────────────────────────────────────────────────

def login_donor(email: str, password: str, ip_address: str = None) -> dict:
    """
    Verify credentials, enforce brute-force lockout, return JWT on success.
    Returns {"success": True, "access_token": ...} or {"success": False, "error": ...}
    """
    donor = Donor.query.filter_by(email=email.lower()).first()

    # Unknown email — don't reveal whether it exists
    if not donor:
        _log(event_type="LOGIN_FAIL", details=f"Unknown email: {email}", ip=ip_address)
        return {"success": False, "error": "Invalid email or password"}

    # Check account lockout
    if donor.locked_until and _utcnow() < donor.locked_until:
        remaining = int((donor.locked_until - _utcnow()).total_seconds() // 60) + 1
        return {"success": False, "error": f"Account locked. Try again in {remaining} minute(s)"}

    # Verify bcrypt hash
    if not bcrypt.check_password_hash(donor.password_hash, password):
        donor.login_attempts += 1
        max_attempts = current_app.config["MAX_LOGIN_ATTEMPTS"]

        if donor.login_attempts >= max_attempts:
            lockout_mins = current_app.config["LOCKOUT_MINUTES"]
            donor.locked_until = _utcnow() + timedelta(minutes=lockout_mins)
            donor.login_attempts = 0
            db.session.commit()
            _log(event_type="ACCOUNT_LOCKED", user_id=donor.id, ip=ip_address,
                 details=f"Locked after {max_attempts} failed attempts")
            return {"success": False,
                    "error": f"Too many failed attempts. Account locked for {lockout_mins} minutes"}

        db.session.commit()
        _log(event_type="LOGIN_FAIL", user_id=donor.id, ip=ip_address,
             details=f"Wrong password (attempt {donor.login_attempts}/{max_attempts})")
        return {"success": False, "error": "Invalid email or password"}

    # Successful login — reset counters
    donor.login_attempts = 0
    donor.locked_until   = None
    db.session.commit()

    access_token = create_access_token(identity=str(donor.id))
    _log(event_type="LOGIN_SUCCESS", user_id=donor.id, ip=ip_address)
    return {"success": True, "access_token": access_token, "donor_id": donor.id, "name": donor.name, "is_admin": donor.is_admin}


# ── Password Utilities ────────────────────────────────────────────────────────

def validate_password_strength(password: str) -> dict:
    """
    Enforce minimum password policy before hashing.
    Returns {"valid": True} or {"valid": False, "error": ...}
    """
    if len(password) < 8:
        return {"valid": False, "error": "Password must be at least 8 characters"}
    if not any(c.isupper() for c in password):
        return {"valid": False, "error": "Password must contain at least one uppercase letter"}
    if not any(c.isdigit() for c in password):
        return {"valid": False, "error": "Password must contain at least one digit"}
    if not any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password):
        return {"valid": False, "error": "Password must contain at least one special character"}
    return {"valid": True}


def get_donor_by_id(donor_id: int) -> Donor | None:
    return db.session.get(Donor, donor_id)


# ── Internal Helpers ──────────────────────────────────────────────────────────

def _log(event_type: str, user_id: int = None, ip: str = None, details: str = None):
    entry = AuditLog(
        event_type = event_type,
        user_id    = user_id,
        ip_address = ip,
        details    = details
    )
    db.session.add(entry)
    db.session.commit()


# ── Admin guard ───────────────────────────────────────────────────────────────

from functools import wraps
from flask import jsonify
from flask_jwt_extended import verify_jwt_in_request, get_jwt_identity

def admin_required(fn):
    """Decorator: blocks non-admin callers with 403."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        verify_jwt_in_request()
        donor = db.session.get(Donor, int(get_jwt_identity()))
        if not donor or not donor.is_admin:
            return jsonify({"error": "Admin access required"}), 403
        return fn(*args, **kwargs)
    return wrapper
